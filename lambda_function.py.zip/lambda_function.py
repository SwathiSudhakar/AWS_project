import json
import os
from collections import defaultdict
from datetime import datetime, timedelta

import boto3

import redshift_connector

# Threshold values
THRESHOLDS = {
    "Signal Strength (dBm)": -80,
    "Data Throughput (Mbps)": 10,
    "Latency (ms)": 100,
    "QCI (Input 6)": 5,
    "Packet Loss Rate (Reliability)": 1,  # 1% or more
    "Packet Delay Budget (Latency)": 100  # ms
}

SNS_TOPIC_ARN = os.environ.get('SNS_TOPIC_ARN')  # Update with your SNS Topic ARN


def calculate_averages(records):
    num_records = len(records)
    return {
        'average_signal_strength_dbm': sum(float(r['signal_strength_dbm']) for r in records) / num_records,
        'average_data_throughput_mbps': sum(r['data_throughput_mbps'] for r in records) / num_records,
        'average_latency_ms': sum(r['latency_ms'] for r in records) / num_records,
        'average_qci_input_6': sum(r['qci_input_6'] for r in records) / num_records,
        'average_packet_loss_rate_reliability': sum(r['packet_loss_rate_reliability'] for r in records) / num_records,
        'average_packet_delay_budget_latency': sum(convert_packet_delay(r['packet_delay_budget_latency'])
                                                   for r in records) / num_records
    }


def check_thresholds(city_average):
    breaches = []
    if city_average['average_signal_strength_dbm'] < THRESHOLDS["Signal Strength (dBm)"]:
        breaches.append("Signal Strength (dBm)")
    if city_average['average_data_throughput_mbps'] < THRESHOLDS["Data Throughput (Mbps)"]:
        breaches.append("Data Throughput (Mbps)")
    if city_average['average_latency_ms'] > THRESHOLDS["Latency (ms)"]:
        breaches.append("Latency (ms)")
    if city_average['average_qci_input_6'] > THRESHOLDS["QCI (Input 6)"]:
        breaches.append("QCI (Input 6)")
    if city_average['average_packet_loss_rate_reliability'] > THRESHOLDS["Packet Loss Rate (Reliability)"]:
        breaches.append("Packet Loss Rate (Reliability)")
    if city_average['average_packet_delay_budget_latency'] > THRESHOLDS["Packet Delay Budget (Latency)"]:
        breaches.append("Packet Delay Budget (Latency)")
    return breaches


def send_sns_alert(sns_client, city, breaches, time_delta):
    message = {
        "City": city,
        "Threshold Breach Fields": breaches,
        "Time Delta": time_delta
    }
    sns_client.publish(
        TopicArn=SNS_TOPIC_ARN,
        Message=json.dumps(message),
        Subject=f"Threshold Breach Detected in {city}"
    )


def convert_packet_delay(time_input):
    # Remove the '<' and 'ms' parts from the string
    numeric_value = time_input.replace('<', '').replace('ms', '').strip()

    # Convert the string to an integer
    return int(numeric_value)


def lambda_handler(event, context):
    sns_client = boto3.client('sns')

    # Redshift connection details
    redshift_config = {
        'host': os.environ['REDSHIFT_HOST'],
        'port': int(os.environ['REDSHIFT_PORT']),
        'database': os.environ['REDSHIFT_DB_NAME'],
        'user': os.environ['REDSHIFT_DB_USER'],
        'password': os.environ['REDSHIFT_DB_PASSWORD']
    }
    table_name = os.environ.get('REDSHIFT_TABLE_NAME', 'public.mobile_signal_data')

    # Calculate the time range for the last X minutes
    delta_time = 240
    end_date = datetime.now()
    start_date = end_date - timedelta(minutes=delta_time)
    time_delta = f"From {start_date.strftime('%Y-%m-%d %H:%M:%S')} to {end_date.strftime('%Y-%m-%d %H:%M:%S')}"

    try:
        # Connect to Redshift and execute the query
        with redshift_connector.connect(**redshift_config) as conn:
            with conn.cursor() as cursor:
                select_sql = f"""
                    SELECT * FROM {table_name}
                    WHERE created BETWEEN %s AND %s;
                """
                cursor.execute(select_sql, (start_date, end_date))
                rows = cursor.fetchall()

        if not rows:
            print("No records found in the specified time range.")
            return {'statusCode': 200, 'body': json.dumps({'message': 'No records found in the specified time range.'})}

        # Group records by city
        grouped_records = defaultdict(list)
        for row in rows:
            city = row[0]  # Assuming city is the first column
            record = {
                'signal_strength_dbm': row[4],
                'data_throughput_mbps': row[5],
                'latency_ms': row[6],
                'qci_input_6': row[9],
                'packet_loss_rate_reliability': row[10],
                'packet_delay_budget_latency': row[11],
            }
            grouped_records[city].append(record)

        # Calculate averages and check thresholds
        city_averages = []
        for city, records in grouped_records.items():
            city_average = calculate_averages(records)
            breaches = check_thresholds(city_average)
            if breaches:
                print(f"Threshold breach detected for city: {city}, fields: {breaches}")
                send_sns_alert(sns_client, city, breaches, time_delta)
            city_average['city'] = city
            city_averages.append(city_average)

        return {'statusCode': 200, 'body': json.dumps(city_averages)}

    except redshift_connector.Error as e:
        print(f"Error while interacting with Redshift: {e}")
        return {'statusCode': 500, 'body': json.dumps({'error': 'Internal server error while querying Redshift.'})}
