import json
import base64
import redshift_connector
import os
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger()

# Redshift connection details
host = os.environ['REDSHIFT_HOST']
port = os.environ['REDSHIFT_PORT']
dbname = os.environ['REDSHIFT_DB_NAME']
user = os.environ['REDSHIFT_DB_USER']
password = os.environ['REDSHIFT_DB_PASSWORD']

def process_record(record):
    try:
        # Decode the Kinesis record
        payload = base64.b64decode(record['kinesis']['data']).decode('utf-8')
        # Process the payload (assuming it's a JSON string)
        data_list = json.loads(payload)
        record_count = len(data_list)
        print(f"record_count : {record_count}")

        # Extract fields from the list of records
        records = []
        for data in data_list:
            record_data = (
                data.get('city'),
                data.get('lat'),
                data.get('lng'),
                data.get('country'),
                data.get('signal_strength_dbm'),
                data.get('data_throughput_mbps'),
                data.get('latency_ms'),
                data.get('network_type'),
                data.get('time_input'),
                data.get('qci_input'),
                data.get('packet_loss_rate_reliability'),
                data.get('packet_delay_budget_latency')
            )
            records.append(record_data)

        return records
    except Exception as e:
        logger.error(f"Error processing record: {e}")
        raise

def insert_into_redshift(records):
    try:
        conn = redshift_connector.connect(
            host=host,
            port=int(port),
            database=dbname,
            user=user,
            password=password
        )
        cursor = conn.cursor()

        # SQL statement for inserting data
        sql = """
            INSERT INTO public.mobile_signal_data (
                city, lat, lng, country, signal_strength_dBm, data_throughput_Mbps, latency_ms,
                network_type, time_input, qci_input, packet_loss_rate_reliability, packet_delay_budget_latency
            ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """
        
        cursor.executemany(sql, records)

        conn.commit()
        cursor.close()
        conn.close()
    except Exception as e:
        logger.error(f"Error inserting into Redshift: {e}")
        raise

def lambda_handler(event, context):
    print(f"event ==> {json.dumps(event)}")
    for record in event.get('Records', []):
        print(f"record ==> {record}")
        logger.info(f"Processing record: {record}")
        try:
            records = process_record(record)
            logger.info(f"Extracted records: {records}")
            insert_into_redshift(records)
        except Exception as e:
            logger.error(f"Error handling record: {e}")

    return {
        'statusCode': 200,
        'body': json.dumps('Records processed successfully')
    }
